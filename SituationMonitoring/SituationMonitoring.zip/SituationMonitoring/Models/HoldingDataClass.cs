﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SituationMonitoring.Models
{
    public class HoldingDataClass
    {

        public static string  situationId { get; set; }
    }
}