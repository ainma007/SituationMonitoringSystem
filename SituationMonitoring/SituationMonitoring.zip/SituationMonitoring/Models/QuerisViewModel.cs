﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SituationMonitoring.Models
{
    public class QuerisViewModel
    {
        public int GetSum_Question { get; set; }
        public double GetSum_Estimated_Number_Of_Individuals { get; set; }
    }
}