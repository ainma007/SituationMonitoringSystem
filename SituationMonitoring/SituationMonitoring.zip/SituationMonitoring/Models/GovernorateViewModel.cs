﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SituationMonitoring.Models
{
    public class GovernorateViewModel
    {
        public int GovernorateID { get; set; }
        public string GovernorateArName { get; set; }
    }
}