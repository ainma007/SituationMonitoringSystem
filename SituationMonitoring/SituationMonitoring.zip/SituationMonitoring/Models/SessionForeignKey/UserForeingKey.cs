﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SituationMonitoring.Models.SessionForeignKey
{
    public class UserForeingKey
    {
        public int UserID { get; set; }
        public string UserFullName { get; set; }

    }
}