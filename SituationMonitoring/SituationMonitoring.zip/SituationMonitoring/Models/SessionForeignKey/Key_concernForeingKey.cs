﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SituationMonitoring.Models.SessionForeignKey
{
    public class Key_concernForeingKey
    {
        public int ID { get; set; }
        public String  Key_concern { get; set; }
    }
}