﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SituationMonitoring.Models.SessionForeignKey
{
    public class SituationForeingKey
    {
        public int SituationID { get; set; }
        public string SituationNo { get; set; }

    }
}