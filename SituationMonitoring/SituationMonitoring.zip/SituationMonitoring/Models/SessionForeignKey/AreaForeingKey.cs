﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SituationMonitoring.Models.SessionForeignKey
{
    public class AreaForeingKey
    {
        public int AreaID { get; set; }
        public String AreaName { get; set; }
    }
}